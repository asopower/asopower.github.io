/* =========================================================
   FX layer — textured background, living cards, animated
   charts, reviews, social dock, scroll-driven extras.
   Loaded after main.js.
   ========================================================= */

/* ✏️ CLIENT REVIEWS — replace these sample reviews with real feedback from your clients */
const REVIEWS = [
  { name: "App Owner", role: "Productivity app · iOS", text: "Our listing finally speaks to the right users. Revenue moved within weeks of the keyword and screenshot overhaul." },
  { name: "Product Lead", role: "Education app · iOS & Android", text: "Ahmed brought clear data, sharp screenshot briefs and weekly reports we actually read. Conversion went up and stayed up." },
  { name: "Studio Founder", role: "Casual games", text: "He localized our store pages for multiple markets and the rankings followed. Easy to work with and very fast." },
  { name: "Marketing Manager", role: "Utility app", text: "Apple Search Ads used to burn budget. After the campaign restructure and Custom Product Pages our cost per install dropped." },
  { name: "Indie Developer", role: "Writing app · iOS", text: "From a quiet launch to steady organic installs. The launch keyword plan was exactly what we needed." },
  { name: "Growth Lead", role: "Subscription app", text: "Great collaboration with our designers. Every screenshot had a reason and every test had a clear winner." }
];

(() => {
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const fine = matchMedia("(pointer:fine)").matches;
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const observe = el => (window.__observe ? window.__observe(el) : el.classList.add("in"));

  /* ---------- background texture layers ---------- */
  document.body.insertAdjacentHTML("afterbegin",
    `<div class="bg-fx" aria-hidden="true"><div class="dots"></div><div class="lines"></div><i class="blob b1"></i><i class="blob b2"></i><i class="blob b3"></i></div><div class="grain" aria-hidden="true"></div>`);

  /* ---------- floating WhatsApp + LinkedIn dock ---------- */
  const C = (typeof CONTACT !== "undefined" ? CONTACT : {});
  const waNum = (C.phoneRaw || "").replace(/\D/g, "");
  const WA = "https://wa.me/" + waNum + "?text=" + encodeURIComponent("Hi Ahmed, I found your ASO portfolio and want to discuss my app.");
  document.body.insertAdjacentHTML("beforeend", `
    <div class="dock">
      <div class="dk-wrap wa-w"><span class="tipl">Chat on WhatsApp</span>
        <a class="dk wa" href="${WA}" target="_blank" rel="noopener" aria-label="WhatsApp">
          <svg viewBox="0 0 24 24"><path d="M12 2.2a9.8 9.8 0 0 0-8.4 14.8L2.3 21.7l4.8-1.3A9.8 9.8 0 1 0 12 2.2z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M8.6 7.3c.25-.55.5-.56.75-.57h.62c.2 0 .45.05.66.5l.86 2.03c.07.18.1.38-.02.58l-.47.66c-.13.18-.2.38-.05.62.5.86 1.26 1.66 2.1 2.2.27.17.47.14.66-.06l.7-.84c.17-.2.38-.24.62-.14l1.86.9c.26.12.4.27.4.5 0 .5-.2 1.2-.72 1.62-.62.5-1.5.72-2.4.43a9.2 9.2 0 0 1-5.7-5.4c-.4-1-.32-2.14.13-3.03z" fill="currentColor"/></svg>
        </a></div>
      <div class="dk-wrap"><span class="tipl">Connect on LinkedIn</span>
        <a class="dk li" href="${C.linkedin || "#"}" target="_blank" rel="noopener" aria-label="LinkedIn">
          <svg viewBox="0 0 24 24" fill="currentColor"><path d="M5 3.6a2.3 2.3 0 1 1 0 4.6 2.3 2.3 0 0 1 0-4.6zM3 9.6h4V21H3zM9.4 9.6h3.8v1.6h.06c.53-.95 1.83-1.95 3.77-1.95 4.03 0 4.77 2.55 4.77 5.87V21h-4v-5.2c0-1.24-.02-2.84-1.8-2.84-1.8 0-2.07 1.36-2.07 2.75V21H9.4z"/></svg>
        </a></div>
    </div>`);
  $$(".dk").forEach(dk => dk.addEventListener("click", e => {
    const r = dk.getBoundingClientRect();
    const rip = document.createElement("span");
    rip.className = "rip";
    rip.style.left = (e.clientX - r.left || r.width / 2) + "px";
    rip.style.top = (e.clientY - r.top || r.height / 2) + "px";
    dk.appendChild(rip);
    dk.classList.remove("pop"); void dk.offsetWidth; dk.classList.add("pop");
    setTimeout(() => rip.parentNode && rip.parentNode.removeChild(rip), 750);
  }));

  /* ---------- floating cursor labels (hero) ---------- */
  $$(".fc").forEach(fc => { const w = document.createElement("div"); w.className = "fl"; while (fc.firstChild) w.appendChild(fc.firstChild); fc.appendChild(w); });
  const fcs = $$(".fc[data-depth]");
  if (fcs.length && fine && !reduce) {
    let tx = 0, ty = 0, cx = 0, cy = 0;
    addEventListener("pointermove", e => { tx = e.clientX / innerWidth - 0.5; ty = e.clientY / innerHeight - 0.5; });
    const loopFc = () => {
      cx += (tx - cx) * 0.06; cy += (ty - cy) * 0.06;
      fcs.forEach(el => { const d = +el.dataset.depth; el.firstChild.style.translate = `${(-cx * d * 2).toFixed(1)}px ${(-cy * d * 2).toFixed(1)}px`; });
      requestAnimationFrame(loopFc);
    };
    loopFc();
  }

  /* ---------- living cards ---------- */
  const cardSel = ".svc,.cb,.ba,.ba-kpi,.tk>div,.ss-why>div,.pl,.panel,.rv,.info,.num,.bp-copy .stat-row>div,.case-row .ic,.ps";
  $$(cardSel).forEach(card => {
    card.classList.add("fx");
    if (getComputedStyle(card).position === "static") card.style.position = "relative";
    if (!card.querySelector(":scope > .shine")) card.insertAdjacentHTML("afterbegin", '<i class="shine" aria-hidden="true"></i>');
    if (!fine) return;
    const tiltMax = card.matches(".pl,.panel,.ba") ? 4 : 9;
    card.addEventListener("pointermove", e => {
      const r = card.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
      card.style.setProperty("--mx", x * 100 + "%");
      card.style.setProperty("--my", y * 100 + "%");
      card.style.setProperty("--ry", ((x - 0.5) * tiltMax).toFixed(2) + "deg");
      card.style.setProperty("--rx", ((0.5 - y) * tiltMax).toFixed(2) + "deg");
    });
    card.addEventListener("pointerleave", () => { card.style.setProperty("--rx", "0deg"); card.style.setProperty("--ry", "0deg"); });
  });

  /* ---------- charts ---------- */
  let gid = 0;
  function rng(seed) { let s = seed % 2147483647 || 1; return () => (s = (s * 16807) % 2147483647, (s - 1) / 2147483646); }
  function gen(kind, n, seed) {
    const r = rng(seed), out = [];
    for (let i = 0; i < n; i++) {
      const t = i / (n - 1); let v;
      switch (kind) {
        case "up": v = 0.28 + 0.5 * t + (r() - 0.5) * 0.16; break;
        case "lift": v = 0.18 + 0.62 * Math.pow(t, 1.5) + (r() - 0.5) * 0.18; break;
        case "spiky": v = 0.45 + 0.12 * Math.sin(i * 0.95) + (r() - 0.5) * 0.34 + 0.12 * t; break;
        case "launch": v = t < 0.75 ? 0.04 + r() * 0.03 : 0.08 + Math.pow((t - 0.75) * 4, 1.3) * (0.55 + r() * 0.35); break;
        case "flat": v = 0.22 + (r() - 0.5) * 0.12; break;
        case "steady": v = 0.55 + 0.08 * Math.sin(i * 0.7) + (r() - 0.5) * 0.18; break;
        default: v = 0.4 + (r() - 0.5) * 0.3;
      }
      out.push(Math.max(0.02, Math.min(0.98, v)));
    }
    return out;
  }
  function smoothPath(pts) {
    let d = `M${pts[0][0].toFixed(1)},${pts[0][1].toFixed(1)}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      const c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
      const c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
      d += ` C${c1x.toFixed(1)},${c1y.toFixed(1)} ${c2x.toFixed(1)},${c2y.toFixed(1)} ${p2[0].toFixed(1)},${p2[1].toFixed(1)}`;
    }
    return d;
  }
  function renderChart(el) {
    const spark = el.classList.contains("spark");
    const n = +(el.dataset.n || (spark ? 30 : 90));
    const W = 600, H = +(el.dataset.h || (spark ? 70 : 230)), P = spark ? 4 : 14;
    const seed = +(el.dataset.seed || 7);
    const A = gen(el.dataset.a || "up", n, seed);
    const B = el.dataset.b ? gen(el.dataset.b, n, seed + 11) : null;
    const pts = arr => arr.map((v, i) => [P + i * (W - 2 * P) / (n - 1), H - P - v * (H - 2 * P)]);
    const pa = pts(A), pb = B ? pts(B) : null;
    const id = "g" + (++gid);
    const dA = smoothPath(pa);
    const area = dA + ` L${pa[n - 1][0]},${H} L${pa[0][0]},${H} Z`;
    const last = pa[n - 1];
    let grid = "";
    if (!spark) for (let k = 1; k <= 4; k++) { const y = (H / 5) * k; grid += `<line x1="0" x2="${W}" y1="${y}" y2="${y}"/>`; }
    el.innerHTML = `
      <svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="${el.dataset.label || "Growth trend"}">
        <defs>
          <linearGradient id="${id}a" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#ff5b1f" stop-opacity=".45"/><stop offset="1" stop-color="#ff5b1f" stop-opacity="0"/></linearGradient>
          <linearGradient id="lnGrad" x1="0" x2="1"><stop offset="0" stop-color="#ff5b1f"/><stop offset="1" stop-color="#ffb27a"/></linearGradient>
        </defs>
        <g class="grid">${grid}</g>
        <path class="area" d="${area}" fill="url(#${id}a)"/>
        ${pb ? `<path class="ln b" d="${smoothPath(pb)}" stroke-dasharray="5 6"/>` : ""}
        <path class="ln a" d="${dA}"/>
        <g class="end"><circle class="pulse" cx="${last[0]}" cy="${last[1]}" r="5" fill="#ff5b1f"/><circle cx="${last[0]}" cy="${last[1]}" r="5" fill="#ffb27a" stroke="#090909" stroke-width="2"/></g>
        ${spark ? "" : `<g class="guide"><line y1="0" y2="${H}" stroke="rgba(255,138,61,.5)" stroke-dasharray="3 4"/><circle r="5" fill="#ff5b1f" stroke="#fff" stroke-width="2"/></g>`}
      </svg>${spark ? "" : '<span class="tip"></span>'}`;
    // draw-in
    $$(".ln", el).forEach(p => {
      const L = p.getTotalLength ? p.getTotalLength() : 1200;
      if (p.classList.contains("b")) { p.style.opacity = "0"; p.style.transition = "opacity 1.2s .4s"; }
      else { p.style.strokeDasharray = L; p.style.strokeDashoffset = L; }
    });
    el.addEventListener("reveal", () => {
      $$(".ln", el).forEach(p => { if (p.classList.contains("b")) p.style.opacity = ".9"; else p.style.strokeDashoffset = 0; });
    });
    if (!spark) {
      const svg = el.querySelector("svg"), guide = el.querySelector(".guide"), tip = el.querySelector(".tip");
      const line = guide.querySelector("line"), dot = guide.querySelector("circle");
      const unit = el.dataset.unit || "Day";
      el.addEventListener("pointermove", e => {
        const r = svg.getBoundingClientRect();
        const i = Math.max(0, Math.min(n - 1, Math.round(((e.clientX - r.left) / r.width * W - P) / ((W - 2 * P) / (n - 1)))));
        const [x, y] = pa[i];
        line.setAttribute("x1", x); line.setAttribute("x2", x);
        dot.setAttribute("cx", x); dot.setAttribute("cy", y);
        tip.style.left = (x / W * 100) + "%"; tip.style.top = (y / H * r.height) + "px";
        tip.textContent = `${unit} ${i + 1}`;
      });
    }
    observe(el);
  }
  $$(".chart").forEach(renderChart);
  window.__renderChart = renderChart;

  /* ring gauges */
  $$(".ring-g").forEach(g => {
    g.insertAdjacentHTML("afterbegin", `<svg viewBox="0 0 120 120" aria-hidden="true"><defs><linearGradient id="rgGrad" x1="0" x2="1"><stop offset="0" stop-color="#ff5b1f"/><stop offset="1" stop-color="#ffb27a"/></linearGradient></defs><circle class="trk" cx="60" cy="60" r="52"/><circle class="val" cx="60" cy="60" r="52"/></svg>`);
  });

  /* dashboard tabs: swap chart per app */
  $$("[data-dash]").forEach(dash => {
    const btns = $$(".tabs button", dash), holder = $(".chart-swap", dash);
    const title = $("[data-dash-title]", dash), big = $("[data-dash-big]", dash), sub = $("[data-dash-sub]", dash);
    btns.forEach(b => b.addEventListener("click", () => {
      if (b.classList.contains("on")) return;
      btns.forEach(x => x.classList.toggle("on", x === b));
      holder.classList.add("out");
      setTimeout(() => {
        const c = holder.querySelector(".chart");
        c.dataset.a = b.dataset.a; c.dataset.b = b.dataset.b || ""; c.dataset.seed = b.dataset.seed;
        if (!b.dataset.b) delete c.dataset.b;
        c.classList.remove("in");
        title.textContent = b.dataset.title; big.textContent = b.dataset.big; sub.textContent = b.dataset.sub;
        renderChart(c);
        holder.classList.remove("out");
        requestAnimationFrame(() => { c.classList.add("in"); c.dispatchEvent(new CustomEvent("reveal")); });
      }, 420);
    }));
  });

  /* ---------- reviews ---------- */
  $$("[data-reviews]").forEach(box => {
    const card = r => `<article class="rv"><span class="q">”</span><div class="stars">${"<span>★</span>".repeat(5)}</div><p>${r.text}</p>
      <div class="who"><span class="av">${r.name.split(" ").map(w => w[0]).join("").slice(0, 2)}</span><div><b>${r.name}</b><small>${r.role}</small></div></div></article>`;
    const half = Math.ceil(REVIEWS.length / 2);
    const rowA = REVIEWS.slice(0, half), rowB = REVIEWS.slice(half).concat(REVIEWS.slice(0, 1));
    box.innerHTML = `<div class="rv-row">${rowA.concat(rowA, rowA).map(card).join("")}</div><div class="rv-row rev">${rowB.concat(rowB, rowB).map(card).join("")}</div>`;
    $$(".rv", box).forEach(c => {
      c.classList.add("fx"); c.insertAdjacentHTML("afterbegin", '<i class="shine" aria-hidden="true"></i>');
      if (!fine) return;
      c.addEventListener("pointermove", e => { const r = c.getBoundingClientRect(); c.style.setProperty("--mx", (e.clientX - r.left) / r.width * 100 + "%"); c.style.setProperty("--my", (e.clientY - r.top) / r.height * 100 + "%"); });
    });
  });

  /* ---------- scroll-driven extras ---------- */
  const speeds = $$("[data-speed]");
  const tracks = $$(".mq-track");
  const tl = $(".tl"), tlLine = tl && $(".tl-line i", tl);
  const curves = $$(".curve-top");
  let lastY = scrollY, vel = 0;
  window.__onScrollFx = y => {
    vel = vel * 0.8 + (y - lastY) * 0.2; lastY = y;
    const sk = Math.max(-8, Math.min(8, vel * 0.25));
    tracks.forEach(t => t.parentElement.style.setProperty("--sk", sk.toFixed(2) + "deg"));
    if (reduce) return;
    speeds.forEach(el => {
      const r = el.getBoundingClientRect();
      const c = (r.top + r.height / 2 - innerHeight / 2);
      el.style.transform = `translate3d(0,${(-c * parseFloat(el.dataset.speed)).toFixed(1)}px,0)`;
    });
    if (tlLine) {
      const r = tl.getBoundingClientRect();
      const p = Math.min(1, Math.max(0, (innerHeight * 0.7 - r.top) / r.height));
      tlLine.parentElement.parentElement.style.setProperty("--tlp", p.toFixed(3));
    }
    curves.forEach(c => {
      const r = c.getBoundingClientRect();
      const p = Math.min(1, Math.max(0, (innerHeight - r.top) / (innerHeight * 0.6)));
      c.style.setProperty("--cv", (1 - p).toFixed(3));
    });
  };
  // marquee skew wrapper
  tracks.forEach(t => t.parentElement.classList.add("mq-skew-host"));
  const style = document.createElement("style");
  style.textContent = ".mq-skew-host .mq-track{transform-origin:center}.mq-skew-host{--sk:0deg}.mq-skew-host .mq-track span{transform:skewX(var(--sk));transition:transform .35s}";
  document.head.appendChild(style);
  window.__onScrollFx(scrollY);
})();

/* replay the logo burst once the 3D intro has finished */
(() => {
  const mk = document.querySelector(".brand .mk.intro");
  const loader = document.querySelector(".loader");
  if (!mk || !loader) return;
  mk.classList.remove("intro");
  const wait = setInterval(() => {
    const l = document.querySelector(".loader");
    if (!l || l.classList.contains("done")) { clearInterval(wait); void mk.offsetWidth; mk.classList.add("intro"); }
  }, 150);
})();

/* tall staggered groups (long lists on phones): reveal as soon as any part is on screen */
(() => {
  const io2 = new IntersectionObserver(es => es.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add("in"); if (e.target.classList.contains("chart")) e.target.dispatchEvent(new CustomEvent("reveal")); io2.unobserve(e.target); }
  }), { threshold: 0, rootMargin: "0px 0px -8% 0px" });
  const arm = () => document.querySelectorAll("[data-stagger],[data-reveal],.chart,.hb-list,.rings").forEach(el => io2.observe(el));
  const wait = setInterval(() => {
    if (document.body.classList.contains("is-entered")) { clearInterval(wait); setTimeout(arm, 400); }
  }, 150);
})();
