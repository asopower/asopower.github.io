/* =========================================================
   Ahmed Javed — portfolio motion system (vanilla JS)
   ========================================================= */

/* ✏️ EDIT YOUR CONTACT DETAILS HERE (used across every page) */
const CONTACT = {
  email: "",                            // optional: add an email later and it appears automatically
  phone: "+92 302 4419641",
  phoneRaw: "+923024419641",            // digits only (for tel: / WhatsApp)
  location: "Faisalabad, Pakistan",
  linkedin: "https://www.linkedin.com/in/ahmed-javed-768871324/"
};

(() => {
  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => [...c.querySelectorAll(s)];
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const finePointer = matchMedia("(pointer:fine)").matches;
  const page = document.body.dataset.page || "home";
  const WA = "https://wa.me/" + CONTACT.phoneRaw.replace(/\D/g, "") + "?text=" + encodeURIComponent("Hi Ahmed, I found your ASO portfolio and want to discuss my app.");
  const mainLink = CONTACT.email ? "mailto:" + CONTACT.email : WA;
  const ext = CONTACT.email ? "" : ' target="_blank" rel="noopener"';
  const store = {
    get(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { sessionStorage.setItem(k, v); } catch (e) {} }
  };

  /* ---------- shared chrome: header, menu, cursor, transition, footer ---------- */
  const navLinks = [["index.html", "Home", "home"], ["work.html", "Work", "work"], ["about.html", "About", "about"]];
  document.body.insertAdjacentHTML("afterbegin", `
    <div class="pt" aria-hidden="true"><i></i><i data-label="Ahmed Javed"></i></div>
    <div class="cursor" aria-hidden="true"></div><div class="cursor-ring" aria-hidden="true"><span></span></div>
    <header class="hdr">
      <a href="index.html" class="brand" data-cursor-link><span class="mk-wrap"><span class="mk${page === "home" ? " intro" : ""}">AJ</span></span><span>Ahmed Javed<small>ASO · ASA Specialist</small></span></a>
      <nav class="nav">${navLinks.map(([h, t, k]) => `<a href="${h}" class="${k === page ? "active" : ""}"><span><b data-t="${t}">${t}</b></span></a>`).join("")}</nav>
      <a href="${mainLink}"${ext} class="btn sm" data-magnetic>Let's talk <span class="ar">↗</span></a>
      <button class="menu-btn" aria-label="Open menu"><i></i><i></i></button>
    </header>
    <div class="mmenu">
      ${navLinks.map(([h, t]) => `<a href="${h}"><span>${t}</span></a>`).join("")}
      <div class="mfoot">${CONTACT.email ? `<a href="mailto:${CONTACT.email}">${CONTACT.email}</a>` : ""}<a href="${WA}" target="_blank" rel="noopener">WhatsApp: ${CONTACT.phone}</a><a href="tel:${CONTACT.phoneRaw}">Call ${CONTACT.phone}</a></div>
    </div>
    <div class="lb" aria-hidden="true"><img alt=""></div>`);

  const footer = $("footer[data-footer]");
  if (footer) footer.outerHTML = `
    <footer>
      <div class="foot">
        <div><a href="index.html" class="brand"><span class="mk">AJ</span><span>Ahmed Javed<small>ASO · ASA Specialist</small></span></a>
          <p style="color:var(--muted);margin-top:18px;max-width:34ch">App Store & Google Play growth — keywords, creatives, localization, A/B tests and paid user acquisition.</p></div>
        <div><h5>Pages</h5>${navLinks.map(([h, t]) => `<a href="${h}">${t}</a>`).join("")}</div>
        <div><h5>Contact</h5>${CONTACT.email ? `<a href="mailto:${CONTACT.email}">${CONTACT.email}</a>` : ""}<a href="${WA}" target="_blank" rel="noopener">WhatsApp ↗</a><a href="tel:${CONTACT.phoneRaw}">${CONTACT.phone}</a></div>
        <div><h5>Based in</h5><p>${CONTACT.location}</p><a href="${CONTACT.linkedin}" target="_blank" rel="noopener">LinkedIn ↗</a></div>
        <div class="copy"><span>© ${new Date().getFullYear()} Ahmed Javed. All rights reserved.</span><span>Ranked. Found. Downloaded.</span></div>
      </div>
      <div class="bigname">AHMED JAVED</div>
    </footer>`;

  $$("[data-email]").forEach(a => {
    if (a.dataset.email === "text") {
      if (!CONTACT.email) { a.style.display = "none"; return; }
      a.href = "mailto:" + CONTACT.email; const b = a.querySelector("b"); if (b) b.textContent = CONTACT.email;
    } else {
      a.href = mainLink;
      if (!CONTACT.email) { a.target = "_blank"; a.rel = "noopener"; a.dataset.cursor = "WhatsApp"; }
    }
  });
  $$("[data-phone]").forEach(a => { a.href = "tel:" + CONTACT.phoneRaw; const b = a.querySelector("b"); if (b) b.textContent = CONTACT.phone; });
  $$("[data-whatsapp]").forEach(a => { a.href = WA; const b = a.querySelector("b"); if (b) b.textContent = "WhatsApp " + CONTACT.phone; });
  $$("[data-linkedin]").forEach(a => { a.href = CONTACT.linkedin; });

  /* ---------- smooth scroll (Lenis if available) ---------- */
  let lenis = null;
  if (!reduce && window.Lenis) {
    lenis = new Lenis({ lerp: 0.075, smoothWheel: true, wheelMultiplier: 0.95, touchMultiplier: 1.4 });
    window.__lenis = lenis;
    const raf = t => { lenis.raf(t); requestAnimationFrame(raf); };
    requestAnimationFrame(raf);
  }
  const stopScroll = () => { document.body.classList.add("is-loading"); lenis && lenis.stop(); };
  const startScroll = () => { document.body.classList.remove("is-loading"); lenis && lenis.start(); };

  /* ---------- split text ---------- */
  let wi = 0;
  function splitWords(el, cls = "w", inner = "wi") {
    let i = 0;
    const walk = node => {
      [...node.childNodes].forEach(n => {
        if (n.nodeType === 3) {
          const frag = document.createDocumentFragment();
          n.textContent.split(/(\s+)/).forEach(part => {
            if (!part) return;
            if (/^\s+$/.test(part)) { frag.appendChild(document.createTextNode(" ")); return; }
            const o = document.createElement("span"); o.className = cls;
            const s = document.createElement("span"); s.className = inner; s.textContent = part;
            s.style.transitionDelay = (i++ * 0.045) + "s";
            o.appendChild(s); frag.appendChild(o);
          });
          n.replaceWith(frag);
        } else if (n.nodeType === 1 && n.tagName !== "BR" && !n.classList.contains("chip")) walk(n);
      });
    };
    walk(el);
  }
  $$("[data-split]").forEach(el => splitWords(el));
  $$("[data-scrub]").forEach(el => {
    const walk = node => [...node.childNodes].forEach(n => {
      if (n.nodeType === 3) {
        const f = document.createDocumentFragment();
        n.textContent.split(/(\s+)/).forEach(p => {
          if (!p) return;
          if (/^\s+$/.test(p)) return f.appendChild(document.createTextNode(" "));
          const s = document.createElement("span"); s.className = "sw"; s.textContent = p; f.appendChild(s);
        });
        n.replaceWith(f);
      } else if (n.nodeType === 1) walk(n);
    });
    walk(el);
  });

  /* ---------- reveal on scroll ---------- */
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add("in");
        e.target.dispatchEvent(new CustomEvent("reveal"));
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.18, rootMargin: "0px 0px -6% 0px" });
  const armReveals = () => $$("[data-split],[data-reveal],[data-count],.ps,[data-bars],[data-stagger],[data-clip],.chart,.rings,.hb-list").forEach(el => io.observe(el));
  window.__observe = el => io.observe(el);

  /* ---------- counters ---------- */
  function countUp(el, to, from = 0, dur = 1800) {
    const dec = +(el.dataset.decimals || 0), pre = el.dataset.prefix || "", suf = el.dataset.suffix || "";
    const t0 = performance.now();
    const step = now => {
      const p = Math.min(1, (now - t0) / dur), e = 1 - Math.pow(1 - p, 4);
      el.textContent = pre + (from + (to - from) * e).toFixed(dec).replace(/\B(?=(\d{3})+(?!\d))/g, ",") + suf;
      if (p < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }
  $$("[data-count]").forEach(el => {
    el.textContent = (el.dataset.prefix || "") + "0" + (el.dataset.suffix || "");
    el.addEventListener("reveal", () => countUp(el, parseFloat(el.dataset.count)));
  });

  /* ---------- cursor ---------- */
  const dot = $(".cursor"), ring = $(".cursor-ring"), ringLabel = ring.querySelector("span");
  let mx = innerWidth / 2, my = innerHeight / 2, rx = mx, ry = my;
  if (finePointer) {
    document.body.classList.add("has-cursor");
    addEventListener("mousemove", e => { mx = e.clientX; my = e.clientY; dot.style.transform = `translate(${mx}px,${my}px)`; });
    addEventListener("mousedown", () => ring.classList.add("is-down"));
    addEventListener("mouseup", () => ring.classList.remove("is-down"));
    const loop = () => {
      rx += (mx - rx) * 0.16; ry += (my - ry) * 0.16;
      ring.style.transform = `translate(${rx}px,${ry}px)`;
      requestAnimationFrame(loop);
    };
    loop();
    document.addEventListener("mouseover", e => {
      const c = e.target.closest("[data-cursor]");
      const l = e.target.closest("a,button");
      ring.classList.toggle("is-hover", !!c);
      ring.classList.toggle("is-link", !c && !!l);
      ringLabel.textContent = c ? c.dataset.cursor : "";
    });
  }

  /* ---------- magnetic elements ---------- */
  if (finePointer) $$("[data-magnetic]").forEach(el => {
    const s = parseFloat(el.dataset.magnetic) || 0.3;
    el.addEventListener("mousemove", e => {
      const r = el.getBoundingClientRect();
      const x = e.clientX - r.left - r.width / 2, y = e.clientY - r.top - r.height / 2;
      el.style.transform = `translate(${x * s}px,${y * s}px)`;
    });
    el.addEventListener("mouseleave", () => { el.style.transform = ""; });
  });

  /* ---------- skill trail on hero (cursor animation) ---------- */
  const trailZone = $("[data-trail]");
  if (trailZone && finePointer && !reduce) {
    const words = ["Keyword Research", "Metadata", "A/B Testing", "Localization", "Apple Search Ads", "Google Ads UAC", "Screenshots", "CVR ↑", "Top 10 Rankings", "Custom Product Pages", "In-App Events", "Competitor Intel", "Icon Tests", "PPO", "Store Experiments", "Installs ↑"];
    let lx = 0, ly = 0, k = 0;
    trailZone.addEventListener("mousemove", e => {
      if (Math.hypot(e.clientX - lx, e.clientY - ly) < 110) return;
      lx = e.clientX; ly = e.clientY;
      const t = document.createElement("span");
      t.className = "trail " + ["", "alt", "ghost"][k % 3];
      t.textContent = words[k++ % words.length];
      t.style.left = e.clientX + "px"; t.style.top = e.clientY + "px";
      t.style.setProperty("--r", (Math.random() * 14 - 7).toFixed(1) + "deg");
      document.body.appendChild(t);
      setTimeout(() => t.remove(), 1300);
    });
  }

  /* ---------- 3D tilt on hover ---------- */
  $$("[data-tilt]").forEach(wrap => {
    const target = wrap.querySelector(".phone3d") || wrap;
    const base = target.style.transform || getComputedStyle(target).transform;
    const bx = parseFloat(wrap.dataset.bx || -22), by = parseFloat(wrap.dataset.by || 10);
    const zone = wrap.closest("section") || wrap;
    if (!finePointer) return;
    zone.addEventListener("mousemove", e => {
      const x = e.clientX / innerWidth - 0.5, y = e.clientY / innerHeight - 0.5;
      target.style.transform = `rotateY(${bx + x * 26}deg) rotateX(${by - y * 18}deg)`;
    });
    zone.addEventListener("mouseleave", () => { target.style.transform = ""; });
  });

  /* ---------- header behaviour ---------- */
  const hdr = $(".hdr");
  let lastY = 0;
  const onScrollHeader = y => {
    hdr.classList.toggle("scrolled", y > 40);
    hdr.classList.toggle("hide", y > lastY && y > 400 && !document.body.classList.contains("menu-open"));
    lastY = y;
  };
  $(".menu-btn").addEventListener("click", () => document.body.classList.toggle("menu-open"));

  /* ---------- scroll-driven effects (scrub text, horizontal track) ---------- */
  const scrubs = $$("[data-scrub]");
  const hs = $(".hs"), hsTrack = hs && $(".hs-track", hs), hsBar = hs && $(".hs-progress i", hs);
  const mqDesk = matchMedia("(min-width:901px)");
  function sizeHS() {
    if (!hs) return;
    if (!mqDesk.matches) { hs.style.height = ""; return; }
    const dist = hsTrack.scrollWidth - innerWidth;
    hs.style.height = (innerHeight + Math.max(0, dist)) + "px";
  }
  function onScroll() {
    const y = scrollY;
    onScrollHeader(y);
    window.__onScrollFx && window.__onScrollFx(y);
    scrubs.forEach(el => {
      const r = el.getBoundingClientRect();
      const p = Math.min(1, Math.max(0, (innerHeight * 0.85 - r.top) / (r.height + innerHeight * 0.35)));
      const ws = el._ws || (el._ws = $$(".sw", el));
      const n = Math.floor(p * ws.length * 1.05);
      ws.forEach((w, i) => w.classList.toggle("on", i < n));
    });
    if (hs && mqDesk.matches) {
      const r = hs.getBoundingClientRect();
      const total = hs.offsetHeight - innerHeight;
      const p = Math.min(1, Math.max(0, -r.top / total));
      hsTrack.style.transform = `translate3d(${-p * (hsTrack.scrollWidth - innerWidth)}px,0,0)`;
      hsBar.style.transform = `scaleX(${p})`;
    }
    // listing anatomy auto-highlight
    if (anatItems.length) {
      let active = null;
      anatItems.forEach(li => { const r = li.getBoundingClientRect(); if (r.top < innerHeight * 0.6) active = li; });
      if (active && !anatHover) setAnat(active.dataset.hot);
    }
  }
  const anatItems = $$(".anat-list li");
  let anatHover = false;
  function setAnat(n) {
    anatItems.forEach(li => li.classList.toggle("on", li.dataset.hot === n));
    $$(".hot").forEach(h => h.classList.toggle("on", h.dataset.n === n));
  }
  anatItems.forEach(li => {
    li.addEventListener("mouseenter", () => { anatHover = true; setAnat(li.dataset.hot); });
    li.addEventListener("mouseleave", () => { anatHover = false; });
  });
  let ticking = false;
  const reqScroll = () => { if (!ticking) { ticking = true; requestAnimationFrame(() => { onScroll(); ticking = false; }); } };
  addEventListener("scroll", reqScroll, { passive: true });
  addEventListener("resize", () => { sizeHS(); reqScroll(); });
  addEventListener("load", () => { sizeHS(); reqScroll(); });
  sizeHS(); onScroll();

  /* ---------- case hover preview (home) ---------- */
  const prev = $(".case-preview");
  if (prev && finePointer) {
    const img = prev.querySelector("img");
    let px = 0, py = 0, tx = 0, ty = 0;
    $$(".case-row").forEach(row => {
      row.addEventListener("mouseenter", () => { img.src = row.dataset.img; prev.classList.add("on"); });
      row.addEventListener("mouseleave", () => prev.classList.remove("on"));
    });
    const loop = () => { tx += (mx - tx) * 0.12; ty += (my - ty) * 0.12; prev.style.left = (tx + 30) + "px"; prev.style.top = (ty - 120) + "px"; requestAnimationFrame(loop); };
    loop();
  }

  /* ---------- before / after toggles (work) ---------- */
  $$(".ba").forEach(ba => {
    const tog = $(".ba-toggle", ba), btns = $$("button", tog), nums = $$("b[data-b]", ba);
    let state = "before";
    const fmt = (el, v) => {
      const dec = +(el.dataset.decimals || 0);
      el.textContent = (el.dataset.prefix || "") + v.toFixed(dec).replace(/\B(?=(\d{3})+(?!\d))/g, ",") + (el.dataset.suffix || "");
    };
    nums.forEach(n => fmt(n, +n.dataset.b));
    const set = s => {
      if (s === state) return;
      btns.forEach(b => b.classList.toggle("on", b.dataset.s === s));
      tog.classList.toggle("after", s === "after"); ba.classList.toggle("after", s === "after");
      nums.forEach(n => {
        const from = +(state === "after" ? n.dataset.a : n.dataset.b), to = +(s === "after" ? n.dataset.a : n.dataset.b);
        countUp(n, to, from, 1100);
      });
      state = s;
    };
    btns.forEach(b => b.addEventListener("click", () => set(b.dataset.s)));
    // auto-flip to "after" once seen
    const o = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { setTimeout(() => set("after"), 900); o.disconnect(); } }), { threshold: .5 });
    o.observe(ba);
  });
  $$("[data-bars]").forEach(box => box.addEventListener("reveal", () => {
    $$(".bar", box).forEach((bar, i) => {
      const b = bar.querySelector(".b"), a = bar.querySelector(".a");
      setTimeout(() => { b.style.width = b.dataset.w + "%"; a.style.width = a.dataset.w + "%"; }, i * 140);
    });
  }));

  /* ---------- screenshot before/after (work) ---------- */
  $$(".ss-app").forEach(app => {
    const btns = $$(".ss-switch button", app);
    btns.forEach(b => b.addEventListener("click", () => {
      btns.forEach(x => x.classList.toggle("on", x === b));
      app.classList.toggle("is-after", b.dataset.s === "after");
    }));
    const o = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { setTimeout(() => btns[1].click(), 1200); o.disconnect(); } }), { threshold: .45 });
    o.observe(app);
  });
  // real screenshots: if an image file exists it replaces the mock
  $$(".shot img").forEach(img => { img.addEventListener("error", () => img.remove()); });

  /* ---------- filter (work) ---------- */
  $$(".filter button").forEach(b => b.addEventListener("click", () => {
    $$(".filter button").forEach(x => x.classList.toggle("on", x === b));
    const f = b.dataset.f;
    $$(".cs").forEach(cs => {
      const show = f === "all" || cs.dataset.cat.includes(f);
      cs.style.display = show ? "" : "none";
    });
    sizeHS(); lenis && lenis.resize && lenis.resize();
  }));

  /* ---------- lightbox ---------- */
  const lb = $(".lb"), lbImg = lb.querySelector("img");
  $$("[data-zoom]").forEach(f => f.addEventListener("click", () => { lbImg.src = f.dataset.zoom; lbImg.alt = f.querySelector("img")?.alt || ""; lb.classList.add("on"); }));
  lb.addEventListener("click", () => lb.classList.remove("on"));
  addEventListener("keydown", e => { if (e.key === "Escape") lb.classList.remove("on"); });

  /* ---------- page transitions ---------- */
  const labels = { "index.html": "Home", "work.html": "Work", "about.html": "About" };
  document.addEventListener("click", e => {
    const a = e.target.closest("a");
    if (!a || a.target === "_blank" || e.metaKey || e.ctrlKey || e.shiftKey) return;
    const href = a.getAttribute("href") || "";
    if (!/\.html(#.*)?$/.test(href)) return;
    e.preventDefault();
    const file = href.split("#")[0];
    $(".pt i:nth-child(2)").dataset.label = labels[file] || "Ahmed Javed";
    document.body.classList.remove("menu-open", "is-entered");
    document.body.classList.add("is-leaving");
    setTimeout(() => { location.href = href; }, reduce ? 0 : 950);
  });
  addEventListener("pageshow", e => { if (e.persisted) { document.body.classList.remove("is-leaving"); document.body.classList.add("is-entered"); } });

  /* ---------- 3D intro (home, once per session) ---------- */
  const loader = $(".loader");
  function playEnter() {
    requestAnimationFrame(() => requestAnimationFrame(() => {
      document.body.classList.remove("is-entering");
      document.body.classList.add("is-entered");
      setTimeout(armReveals, 350);
    }));
  }

  if (loader && !store.get("aj-intro") && !reduce) {
    stopScroll();
    document.body.classList.remove("is-entering");
    // build ring of ASO words
    const ringWords = ["Keywords", "Rankings", "Conversion", "Localization", "A/B Tests", "Screenshots", "Search Ads", "Google Ads", "Metadata", "Installs"];
    const outer = ["App Store", "Google Play", "ASO", "ASA", "UAC", "CPP", "PPO", "CVR", "Top 10", "ROAS", "Icons", "Events"];
    const mkRing = (el, arr, z) => arr.forEach((w, i) => {
      const s = document.createElement("span"); s.textContent = w;
      s.style.setProperty("--a", (360 / arr.length * i) + "deg"); s.style.setProperty("--z", z);
      el.appendChild(s);
    });
    mkRing($(".ring.r1", loader), ringWords.concat(outer.slice(0, 4)), "clamp(200px,27vw,400px)");

    // camera follows cursor (3D)
    const scene = $(".loader-scene", loader);
    const onMove = e => {
      const x = e.clientX / innerWidth - .5, y = e.clientY / innerHeight - .5;
      scene.style.transform = `rotateY(${x * 22}deg) rotateX(${-y * 16}deg)`;
    };
    addEventListener("mousemove", onMove);

    // typed search + rank climb
    const q = $(".loader-search .q", loader), res = $(".loader-search .res", loader);
    const query = "scan to pdf";
    let qi = 0;
    const typer = setInterval(() => { q.textContent = query.slice(0, ++qi); if (qi >= query.length) clearInterval(typer); }, 110);
    const ranks = $$(".tile3d .rank", loader);
    window.AJ3D && window.AJ3D.start(loader);
    const count = $(".loader-count span", loader), bar = $(".loader-bar", loader);
    const words = $(".loader-word b", loader);
    const steps = ["Researching keywords", "Optimizing metadata", "Testing screenshots", "Localizing listings", "Scaling with Search Ads", "Ranking #1"];
    const t0 = performance.now(), DUR = 4200;
    const tick = now => {
      const p = Math.min(1, (now - t0) / DUR), e = 1 - Math.pow(1 - p, 3);
      count.textContent = Math.round(e * 100);
      bar.style.width = e * 100 + "%";
      const rank = Math.max(1, Math.round(50 - e * 49));
      ranks.forEach(r => r.textContent = "#" + rank);
      window.AJ3D && window.AJ3D.rank(rank);
      res.textContent = "RANK #" + rank;
      words.textContent = steps[Math.min(steps.length - 1, Math.floor(e * steps.length))];
      if (p < 1) requestAnimationFrame(tick);
      else {
        setTimeout(() => {
          loader.classList.add("exit");
          window.AJ3D && window.AJ3D.exit();
          setTimeout(() => {
            loader.classList.add("done");
            removeEventListener("mousemove", onMove);
            startScroll();
            document.body.classList.add("is-entered");
            setTimeout(armReveals, 250);
            setTimeout(() => { window.AJ3D && window.AJ3D.stop(); loader.remove(); }, 1300);
          }, 450);
        }, 350);
      }
    };
    requestAnimationFrame(tick);
    store.set("aj-intro", "1");
  } else {
    if (loader) loader.remove();
    playEnter();
  }
})();
