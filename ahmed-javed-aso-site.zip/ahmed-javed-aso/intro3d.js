/* =========================================================
   3D intro — App Store & Google Play icons (Three.js r128)
   Falls back to the CSS 3D tiles when WebGL is unavailable.
   ========================================================= */
window.AJ3D = (() => {
  let renderer, scene, camera, raf, icons = [], badges = [], particles, ring, ring2, t0, exiting = 0, exitT = 0, mouse = { x: 0, y: 0 }, lastRank = -1, alive = false;

  function canvasTex(draw, size = 512) {
    const c = document.createElement("canvas"); c.width = c.height = size;
    const g = c.getContext("2d"); draw(g, size);
    const t = new THREE.CanvasTexture(c); t.anisotropy = 4; t.encoding = THREE.sRGBEncoding; return t;
  }
  function rrect(g, x, y, w, h, r) {
    g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r);
    g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
  }
  const appStoreFace = (g, s) => {
    const gr = g.createLinearGradient(0, 0, 0, s); gr.addColorStop(0, "#22d0ff"); gr.addColorStop(1, "#0a60ff");
    g.fillStyle = gr; g.fillRect(0, 0, s, s);
    const hl = g.createRadialGradient(s * .3, s * .2, 10, s * .3, s * .2, s * .8); hl.addColorStop(0, "rgba(255,255,255,.35)"); hl.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = hl; g.fillRect(0, 0, s, s);
    g.strokeStyle = "#fff"; g.lineWidth = s * .075; g.lineCap = "round";
    const L = (a, b, c, d) => { g.beginPath(); g.moveTo(a * s, b * s); g.lineTo(c * s, d * s); g.stroke(); };
    L(.33, .74, .58, .29); L(.42, .29, .46, .36); L(.67, .74, .55, .53); L(.24, .62, .76, .62);
  };
  const playFace = (g, s) => {
    const gr = g.createLinearGradient(0, 0, s, s); gr.addColorStop(0, "#1d1d1d"); gr.addColorStop(1, "#060606");
    g.fillStyle = gr; g.fillRect(0, 0, s, s);
    const tri = (pts, col) => { g.beginPath(); g.moveTo(pts[0] * s, pts[1] * s); for (let i = 2; i < pts.length; i += 2) g.lineTo(pts[i] * s, pts[i + 1] * s); g.closePath(); g.fillStyle = col; g.fill(); };
    tri([.3, .18, .3, .82, .6, .5], "#00c3ff");
    tri([.3, .18, .72, .41, .6, .5], "#00e676");
    tri([.3, .82, .6, .5, .72, .59], "#ff3d57");
    tri([.72, .41, .84, .5, .72, .59, .6, .5], "#ffcc00");
    const hl = g.createRadialGradient(s * .25, s * .15, 10, s * .25, s * .15, s * .9); hl.addColorStop(0, "rgba(255,255,255,.18)"); hl.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = hl; g.fillRect(0, 0, s, s);
  };
  const badgeTex = n => canvasTex((g, s) => {
    g.clearRect(0, 0, s, s * .5);
    rrect(g, 8, 8, s - 16, s * .5 - 16, 46); g.fillStyle = "#ff5b1f"; g.fill();
    g.fillStyle = "#0a0a0a"; g.font = `900 ${s * .27}px Archivo, Arial, sans-serif`; g.textAlign = "center"; g.textBaseline = "middle";
    g.fillText("#" + n, s / 2, s * .255);
  }, 256);

  function roundedShape(w, h, r) {
    const s = new THREE.Shape(), x = -w / 2, y = -h / 2;
    s.moveTo(x + r, y); s.lineTo(x + w - r, y); s.quadraticCurveTo(x + w, y, x + w, y + r);
    s.lineTo(x + w, y + h - r); s.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    s.lineTo(x + r, y + h); s.quadraticCurveTo(x, y + h, x, y + h - r);
    s.lineTo(x, y + r); s.quadraticCurveTo(x, y, x + r, y); return s;
  }
  function makeIcon(faceDraw, bodyColor) {
    const group = new THREE.Group();
    const W = 2, R = 0.46;
    const body = new THREE.ExtrudeGeometry(roundedShape(W, W, R), { depth: 0.34, bevelEnabled: true, bevelThickness: 0.12, bevelSize: 0.1, bevelSegments: 8, curveSegments: 28 });
    body.center();
    const bodyMat = new THREE.MeshStandardMaterial({ color: bodyColor, roughness: 0.32, metalness: 0.25 });
    group.add(new THREE.Mesh(body, bodyMat));
    const faceGeo = new THREE.ShapeGeometry(roundedShape(W, W, R), 28);
    const uv = faceGeo.attributes.uv, pos = faceGeo.attributes.position;
    for (let i = 0; i < uv.count; i++) uv.setXY(i, (pos.getX(i) + W / 2) / W, (pos.getY(i) + W / 2) / W);
    const face = new THREE.Mesh(faceGeo, (() => { const tx = canvasTex(faceDraw); return new THREE.MeshStandardMaterial({ map: tx, emissive: 0xffffff, emissiveMap: tx, emissiveIntensity: 0.5, roughness: 0.25, metalness: 0.05 }); })());
    face.position.z = 0.296;
    group.add(face);
    return group;
  }

  function start(loader) {
    if (!window.THREE) return;
    try {
      const cv = document.createElement("canvas"); cv.className = "gl";
      renderer = new THREE.WebGLRenderer({ canvas: cv, antialias: true, alpha: true, powerPreference: "high-performance" });
    } catch (e) { return; }
    if (!renderer || !renderer.getContext()) return;
    const stage = loader.querySelector(".loader-stage");
    loader.insertBefore(renderer.domElement, loader.firstChild);
    loader.insertAdjacentHTML("beforeend", '<div class="loader-flash"></div>');
    loader.classList.add("webgl");
    renderer.setPixelRatio(Math.min(2, devicePixelRatio || 1));
    renderer.outputEncoding = THREE.sRGBEncoding;

    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(38, 1, 0.1, 100);
    camera.position.set(0, 0, 9.5);

    scene.add(new THREE.AmbientLight(0xffffff, 0.35));
    const key = new THREE.DirectionalLight(0xffffff, 0.75); key.position.set(3, 4, 6); scene.add(key);
    const rim = new THREE.DirectionalLight(0xff7a3d, 1.4); rim.position.set(-5, -2, -3); scene.add(rim);
    const orange = new THREE.PointLight(0xff5b1f, 1.2, 14); orange.position.set(0, -1.5, 3); scene.add(orange);
    scene.userData.orange = orange;

    const a = makeIcon(appStoreFace, 0x0756d6); a.position.set(-1.65, 0.55, 0);
    const p = makeIcon(playFace, 0x0b0b0b); p.position.set(1.65, 0.55, 0);
    icons = [a, p];
    icons.forEach((ic, i) => { ic.scale.setScalar(0.001); ic.userData = { phase: i * Math.PI, baseX: ic.position.x }; scene.add(ic); });

    // rank badges as sprites
    badges = icons.map(ic => {
      const m = new THREE.SpriteMaterial({ map: badgeTex(50), transparent: true, depthTest: false });
      const s = new THREE.Sprite(m); s.scale.set(0.95, 0.475, 1); s.position.set(1.0, 1.15, 0.6); s.renderOrder = 5;
      ic.add(s); return s;
    });

    // orbit rings
    const rgeo = new THREE.TorusGeometry(3.4, 0.012, 8, 160);
    ring = new THREE.Mesh(rgeo, new THREE.MeshBasicMaterial({ color: 0xff5b1f, transparent: true, opacity: 0.55 }));
    ring.rotation.x = Math.PI / 2.25; ring.position.y = 0.4; scene.add(ring);
    ring2 = new THREE.Mesh(new THREE.TorusGeometry(4.3, 0.008, 8, 160), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.18 }));
    ring2.rotation.x = Math.PI / 2.6; ring2.rotation.y = 0.3; ring2.position.y = 0.4; scene.add(ring2);
    // orbiting dots on the ring (keyword "planets")
    const dots = new THREE.Group();
    for (let i = 0; i < 9; i++) {
      const m = new THREE.Mesh(new THREE.SphereGeometry(i % 3 === 0 ? 0.09 : 0.05, 16, 16), new THREE.MeshBasicMaterial({ color: i % 3 === 0 ? 0xff5b1f : 0xffe2cc }));
      const ang = i / 9 * Math.PI * 2; m.position.set(Math.cos(ang) * 3.4, Math.sin(ang) * 3.4, 0); dots.add(m);
    }
    ring.add(dots);

    // particle field
    const N = 900, pg = new THREE.BufferGeometry(), arr = new Float32Array(N * 3), col = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      const r = 4 + Math.random() * 9, th = Math.random() * Math.PI * 2, ph = Math.acos(2 * Math.random() - 1);
      arr[i * 3] = r * Math.sin(ph) * Math.cos(th); arr[i * 3 + 1] = r * Math.sin(ph) * Math.sin(th) * 0.6; arr[i * 3 + 2] = r * Math.cos(ph) - 3;
      const o = Math.random() < 0.35; col[i * 3] = 1; col[i * 3 + 1] = o ? 0.42 : 0.9; col[i * 3 + 2] = o ? 0.15 : 0.85;
    }
    pg.setAttribute("position", new THREE.BufferAttribute(arr, 3));
    pg.setAttribute("color", new THREE.BufferAttribute(col, 3));
    particles = new THREE.Points(pg, new THREE.PointsMaterial({ size: 0.035, vertexColors: true, transparent: true, opacity: 0.85, depthWrite: false }));
    scene.add(particles);

    const resize = () => {
      const w = innerWidth, h = innerHeight;
      renderer.setSize(w, h, false); camera.aspect = w / h;
      camera.position.z = Math.max(9.5, 3.6 / (0.344 * camera.aspect));
      camera.updateProjectionMatrix();
    };
    resize(); addEventListener("resize", resize);
    addEventListener("pointermove", e => { mouse.x = e.clientX / innerWidth - 0.5; mouse.y = e.clientY / innerHeight - 0.5; });

    t0 = performance.now(); alive = true;
    const easeOut = x => 1 - Math.pow(1 - x, 4);
    const loop = now => {
      if (!alive) return;
      const t = (now - t0) / 1000;
      icons.forEach((ic, i) => {
        const appear = easeOut(Math.min(1, Math.max(0, (t - 0.15 - i * 0.18) / 1.1)));
        let sc = appear;
        const d = ic.userData;
        ic.rotation.y = Math.sin(t * 0.9 + d.phase) * 0.55 + (1 - appear) * (i ? -3 : 3);
        ic.rotation.x = Math.sin(t * 0.7 + d.phase) * 0.18 - mouse.y * 0.5;
        ic.rotation.z = Math.sin(t * 0.5 + d.phase) * 0.06;
        ic.position.y = 0.55 + Math.sin(t * 1.3 + d.phase) * 0.14;
        if (exiting) {
          const e = Math.min(1, (now - exitT) / 900);
          const k = e * e;
          ic.position.z = k * 7.5; ic.position.x = d.baseX * (1 + k * 1.6);
          ic.rotation.y += k * (i ? -4 : 4);
          sc *= 1 + k * 0.4;
        }
        ic.scale.setScalar(Math.max(0.001, sc));
      });
      ring.rotation.z = t * 0.35; ring2.rotation.z = -t * 0.2;
      particles.rotation.y = t * 0.04 + mouse.x * 0.3; particles.rotation.x = mouse.y * 0.15;
      scene.userData.orange.position.x = Math.sin(t * 0.8) * 3;
      camera.position.x += (mouse.x * 1.6 - camera.position.x) * 0.05;
      camera.position.y += (-mouse.y * 1.0 - camera.position.y) * 0.05;
      camera.lookAt(0, 0.3, 0);
      renderer.render(scene, camera);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
  }
  function rank(n) {
    if (!alive || n === lastRank) return; lastRank = n;
    badges.forEach(b => { const old = b.material.map; b.material.map = badgeTex(n); b.material.needsUpdate = true; old && old.dispose(); });
  }
  function exit() { if (alive) { exiting = 1; exitT = performance.now(); } }
  function stop() {
    alive = false; cancelAnimationFrame(raf);
    if (renderer) { renderer.dispose(); renderer.forceContextLoss && renderer.forceContextLoss(); }
  }
  return { start, rank, exit, stop };
})();
